<div id="not_message_yet">
    <div>
        <div id="new_message_avtar" style="background-image:url('<?php echo $image;?>')"></div>
        <h4 id="new_message_name"><?php echo $name;?></h4>
        <p id="new_message_title" class="text-center">Start messaging with your friend</p>
    </div>
</div>